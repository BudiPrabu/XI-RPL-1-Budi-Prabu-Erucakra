<?php include 'db.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Tambah Kontak</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h2>➕ Tambah Kontak</h2>
    <form method="POST">
        <label>Nama</label>
        <input type="text" name="nama" required>
        <label>Email</label>
        <input type="email" name="email" required>
        <label>Nomor HP</label>
        <input type="text" name="no_hp" required>
        <button type="submit" class="button btn-blue">💾 Simpan</button>
        <a href="index.php" class="button btn-gray">🔙 Kembali</a>
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $nama = $_POST['nama'];
        $email = $_POST['email'];
        $no_hp = $_POST['no_hp'];
        mysqli_query($conn, "INSERT INTO kontak (nama, email, no_hp) VALUES ('$nama', '$email', '$no_hp')");
        header("Location: index.php");
    }
    ?>
</body>
</html>
